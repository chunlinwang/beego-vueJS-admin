/** When your routing table is too long, you can split it into small modules**/

import Layout from '@/views/layout/Layout'

const menuRouter = {
  path: '/menu',
  component: Layout,
  redirect: '/menu/menu1/menu1-1',
  name: 'Menu',
  meta: {
    title: 'Menu',
    icon: 'list'
  },
  children: [
    {
      path: 'create',
      component: () => import('@/views/menu/create'),
      name: 'CreateArticle',
      meta: { title: 'createArticle', icon: 'edit' }
    },
    {
      path: 'edit/:id(\\d+)',
      component: () => import('@/views/menu/edit'),
      name: 'EditArticle',
      meta: { title: 'editArticle', noCache: true },
      hidden: true
    },
    {
      path: 'list',
      component: () => import('@/views/menu/list'),
      name: 'ArticleList',
      meta: { title: 'articleList', icon: 'list' }
    }
  ]
}

export default menuRouter
